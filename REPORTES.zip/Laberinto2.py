"""
LABERINTO: RESOLVEDOR CON BFS, DFS Y UCS
=========================================
Este programa implementa tres algoritmos de búsqueda no informada para resolver laberintos:
- BFS (Breadth-First Search): Búsqueda en Anchura
- DFS (Depth-First Search): Búsqueda en Profundidad  
- UCS (Uniform Cost Search): Búsqueda de Costo Uniforme

El programa carga laberintos desde archivos de texto, donde cada carácter representa:
• 'S' - Punto de inicio (Start)
• 'G' - Meta (Goal)
• '#' - Pared (obstáculo infranqueable)
• '.' - Camino libre (costo = 1)
• ',' - Terreno difícil (costo = 5)
• '~' - Agua/pantano (costo = 10)

Autor: [Neisan Coca]
Fecha: [20/08/25]
"""

import collections  # Para usar deque (cola eficiente)
import time         # Para medir tiempos de ejecución
import os           # Para verificar existencia de archivos
import heapq        # Para la cola de prioridad de UCS
from colorama import init, Fore, Back, Style  # Para colores en consola

# =============================================================================
# CONFIGURACIÓN INICIAL Y CONSTANTES
# =============================================================================

# Inicializar colorama (necesario para Windows, inocuo en Unix/Linux)
init(autoreset=True)

# Diccionario global de costos para cada tipo de terreno
# Define el costo de moverse a través de cada tipo de celda
COSTOS = {
    '.': 1,   # camino libre - costo mínimo
    ',': 5,   # terreno difícil - costo moderado
    '~': 10,  # agua/pantano - costo alto
    'S': 0,   # inicio - sin costo (ya estamos aquí)
    'G': 1    # meta - mismo costo que camino libre
}

# =============================================================================
# FUNCIONES PRINCIPALES
# =============================================================================

def cargar_laberinto(ruta):
    """
    Carga un laberinto desde un archivo de texto y lo convierte en matriz.
    
    Parámetros:
    ruta (str): Ruta del archivo .txt con el laberinto
    
    Retorna:
    list: Matriz 2D (lista de listas) representando el laberinto
    None: Si ocurre un error al cargar el archivo
    
    Estructura de retorno:
    [
        ['#', 'S', '.', '#'],
        ['.', '#', ',', '~'],
        ['G', '.', '#', '.']
    ]
    """
    try:
        with open(ruta, 'r') as archivo:
            # Lee cada línea, elimina espacios y convierte en lista de caracteres
            laberinto = [list(linea.strip()) for linea in archivo.readlines()]
        return laberinto
    # Manejo de exepciones 
    except FileNotFoundError:
        print(f"\nError: El archivo '{ruta}' no se encontró.")
        return None
    except Exception as e:
        print(f"\nError inesperado al leer el archivo: {e}")
        return None

def encontrar_inicio(laberinto):
    """
    Encuentra las coordenadas del punto de inicio 'S' en la matriz del laberinto.
    
    Parámetros:
    laberinto (list): Matriz 2D del laberinto
    
    Retorna:
    tuple: Coordenadas (fila, columna) del inicio
    None: Si no se encuentra el punto de inicio
    
    Ejemplo:
    Para el laberinto [['S', '.'], ['#', 'G']] retorna (0, 0)
    """
    # Itera sobre cada fila y cada columna de la matriz
    for i, fila in enumerate(laberinto):
        for j, celda in enumerate(fila):
            if celda == 'S':
                return (i, j)  # Retorna coordenadas cuando encuentra 'S'
    return None

def es_transitable(laberinto, fila, col):
    """
    Verifica si una celda específica es transitable (no es pared y está dentro de límites).
    
    Parámetros:
    laberinto (list): Matriz del laberinto
    fila (int): Índice de fila a verificar
    col (int): Índice de columna a verificar
    
    Retorna:
    bool: True si la celda es transitable, False si es pared o está fuera de límites
    """
    # Verifica que las coordenadas estén dentro de los límites de la matriz
    if fila < 0 or fila >= len(laberinto) or col < 0 or col >= len(laberinto[0]):
        return False
    
    # Verifica que la celda no sea una pared
    return laberinto[fila][col] != '#'

def obtener_costo(celda):
    """
    Obtiene el costo de moverse a través de un tipo específico de celda.
    
    Parámetros:
    celda (str): Carácter que representa el tipo de celda ('.', ',', '~', etc.)
    
    Retorna:
    int: Costo de moverse por esa celda según el diccionario COSTOS
    
    Ejemplo:
    obtener_costo(',') retorna 5
    obtener_costo('X') retorna 1 (valor por defecto)
    """
    return COSTOS.get(celda, 1)  # Retorna 1 si el carácter no está en el diccionario


def bfs(laberinto):
    """
    Resuelve el laberinto usando Búsqueda en Anchura (Breadth-First Search).
    
    Estrategia: Explora todos los nodos en el nivel actual antes de pasar al siguiente nivel.
    Garantiza encontrar el camino con menor número de pasos (pero no necesariamente menor costo).
    
    Parámetros:
    laberinto (list): Matriz del laberinto a resolver
    
    Retorna:
    tuple: (camino, costo_total, nodos_visitados, longitud_camino)
    - camino: Lista de coordenadas desde inicio hasta meta
    - costo_total: Suma de costos de todas las celdas del camino
    - nodos_visitados: Cantidad total de nodos explorados
    - longitud_camino: Número de movimientos (pasos) del camino
    
    None: Si no se encuentra solución
    """
    inicio = encontrar_inicio(laberinto)
    if not inicio:
        return None, 0, 0, 0

    # Estructura de datos: COLA (FIFO - First In, First Out)
    # Almacena tuplas: (fila, columna, camino_historico, costo_acumulado)
    cola = collections.deque()
    cola.append((inicio[0], inicio[1], [inicio], 0))
    
    visitados = set()  # Conjunto para nodos ya visitados (evita ciclos)
    visitados.add(inicio)
    nodos_visitados = 0  # Contador de nodos explorados

    # Direcciones de movimiento: Arriba, Abajo, Izquierda, Derecha
    direcciones = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while cola:
        # Extrae el PRIMER nodo de la cola (FIFO)
        fila_actual, col_actual, camino_actual, costo_actual = cola.popleft()
        nodos_visitados += 1

        # Verifica si llegamos a la meta
        if laberinto[fila_actual][col_actual] == 'G':
            longitud = len(camino_actual) - 1  # Número de movimientos
            return camino_actual, costo_actual, nodos_visitados, longitud

        # Explora los 4 vecinos adyacentes
        for df, dc in direcciones:
            nueva_fila, nueva_col = fila_actual + df, col_actual + dc
            
            # Verifica si el vecino es transitable y no ha sido visitado
            if es_transitable(laberinto, nueva_fila, nueva_col) and (nueva_fila, nueva_col) not in visitados:
                
                # Calcula nuevo costo acumulado
                nuevo_costo = costo_actual + obtener_costo(laberinto[nueva_fila][nueva_col])
                nuevo_camino = camino_actual + [(nueva_fila, nueva_col)]
                
                # Agrega el nuevo nodo al FINAL de la cola
                cola.append((nueva_fila, nueva_col, nuevo_camino, nuevo_costo))
                visitados.add((nueva_fila, nueva_col))

    return None, 0, nodos_visitados, 0  # No se encontró solución

def dfs(laberinto):
    """
    Resuelve el laberinto usando Búsqueda en Profundidad (Depth-First Search).
    
    Estrategia: Explora un camino hasta el final antes de retroceder (backtracking).
    No garantiza optimalidad pero puede ser más eficiente en memoria.
    
    Parámetros y retornos: igual que la función bfs()
    """
    inicio = encontrar_inicio(laberinto)
    if not inicio:
        return None, 0, 0, 0

    # Estructura de datos: PILA (LIFO - Last In, First Out)
    # Almacena tuplas: (fila, columna, camino_historico, costo_acumulado)
    pila = []
    pila.append((inicio[0], inicio[1], [inicio], 0))
    
    visitados = set()
    visitados.add(inicio)
    nodos_visitados = 0

    direcciones = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while pila:
        # Extrae el ÚLTIMO nodo de la pila (LIFO)
        fila_actual, col_actual, camino_actual, costo_actual = pila.pop()
        nodos_visitados += 1

        if laberinto[fila_actual][col_actual] == 'G':
            longitud = len(camino_actual) - 1
            return camino_actual, costo_actual, nodos_visitados, longitud

        for df, dc in direcciones:
            nueva_fila, nueva_col = fila_actual + df, col_actual + dc
            
            if es_transitable(laberinto, nueva_fila, nueva_col) and (nueva_fila, nueva_col) not in visitados:
                nuevo_costo = costo_actual + obtener_costo(laberinto[nueva_fila][nueva_col])
                nuevo_camino = camino_actual + [(nueva_fila, nueva_col)]
                
                # Agrega el nuevo nodo al FINAL de la pila
                pila.append((nueva_fila, nueva_col, nuevo_camino, nuevo_costo))
                visitados.add((nueva_fila, nueva_col))

    return None, 0, nodos_visitados, 0

def ucs(laberinto):
    """
    Resuelve el laberinto usando Búsqueda de Costo Uniforme (Uniform Cost Search).
    
    Estrategia: Expande el nodo con menor costo acumulado primero.
    Garantiza encontrar el camino con menor costo total (óptimo en costo).
    
    Parámetros y retornos: igual que las funciones anteriores
    """
    inicio = encontrar_inicio(laberinto)
    if not inicio:
        return None, 0, 0, 0

    # Estructura de datos: COLA DE PRIORIDAD (heap)
    # Almacena tuplas: (costo_acumulado, fila, columna, camino_historico)
    # El heap mantiene automáticamente el menor costo primero
    cola_prioridad = []
    heapq.heappush(cola_prioridad, (0, inicio[0], inicio[1], [inicio]))
    
    visitados = {}  # Diccionario para mantener el mejor costo por nodo
    mejores_costos = {inicio: 0}  # Mejor costo conocido para cada nodo
    nodos_visitados = 0

    direcciones = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while cola_prioridad:
        # Extrae el nodo con MENOR COSTO ACUMULADO del heap
        costo_actual, fila_actual, col_actual, camino_actual = heapq.heappop(cola_prioridad)
        nodos_visitados += 1

        # Si encontramos un camino más costoso a este nodo, lo ignoramos
        if (fila_actual, col_actual) in visitados and visitados[(fila_actual, col_actual)] < costo_actual:
            continue

        if laberinto[fila_actual][col_actual] == 'G':
            longitud = len(camino_actual) - 1
            return camino_actual, costo_actual, nodos_visitados, longitud

        # Marca este nodo como visitado con el costo actual
        visitados[(fila_actual, col_actual)] = costo_actual

        for df, dc in direcciones:
            nueva_fila, nueva_col = fila_actual + df, col_actual + dc
            
            if es_transitable(laberinto, nueva_fila, nueva_col):
                # Calcula el nuevo costo para llegar a este vecino
                nuevo_costo = costo_actual + obtener_costo(laberinto[nueva_fila][nueva_col])
                nuevo_camino = camino_actual + [(nueva_fila, nueva_col)]
                
                # Solo considera este camino si es mejor que los conocidos
                if (nueva_fila, nueva_col) not in visitados or nuevo_costo < visitados.get((nueva_fila, nueva_col), float('inf')):
                    heapq.heappush(cola_prioridad, (nuevo_costo, nueva_fila, nueva_col, nuevo_camino))
                    mejores_costos[(nueva_fila, nueva_col)] = nuevo_costo

    return None, 0, nodos_visitados, 0

def guardar_solucion(laberinto, camino, nombre_archivo):
    """
    Guarda el laberinto con el camino solución marcado en un archivo de texto.
    
    Parámetros:
    laberinto (list): Matriz original del laberinto
    camino (list): Lista de coordenadas del camino solución
    nombre_archivo (str): Nombre del archivo donde guardar la solución
    
    El camino se marca con '*' excepto en el inicio (S) y meta (G)
    """
    # Crea una copia profunda para no modificar el original
    laberinto_copia = [fila.copy() for fila in laberinto]

    # Marca cada paso del camino con '*'
    for paso in camino:
        fila, col = paso
        if laberinto_copia[fila][col] not in ['S', 'G']:
            laberinto_copia[fila][col] = '*'

    # Escribe la matriz en el archivo
    with open(nombre_archivo, 'w') as archivo:
        for fila in laberinto_copia:
            linea = ''.join(fila)  # Convierte lista de chars a string
            archivo.write(linea + '\n')

def imprimir_laberinto_color(laberinto, camino=None):
    """
    Imprime el laberinto en la consola con colores para mejor visualización.
    
    Parámetros:
    laberinto (list): Matriz del laberinto a mostrar
    camino (list): Opcional - camino solución a resaltar
    
    Esquema de colores:
    - Amarillo: Punto de inicio (S)
    - Rojo: Meta (G) 
    - Verde: Camino solución (*)
    - Azul: Terreno difícil (,)
    - Cian: Agua/pantano (~)
    - Gris tenue: Paredes (#)
    - Blanco: Camino libre (.)
    """
    for i, fila in enumerate(laberinto):
        for j, celda in enumerate(fila):
            # Si hay camino solución y esta celda está en él
            if camino and (i, j) in camino:
                if celda == 'S':
                    print(Fore.YELLOW + celda, end='')
                elif celda == 'G':
                    print(Fore.RED + celda, end='')
                else:
                    print(Fore.GREEN + '*', end='')  # Marca camino con verde
            else:
                # Colorea según el tipo de celda
                if celda == 'S':
                    print(Fore.YELLOW + celda, end='')
                elif celda == 'G':
                    print(Fore.RED + celda, end='')
                elif celda == '#':
                    print(Style.DIM + celda, end='')  # Paredes tenues
                elif celda == ',':
                    print(Fore.BLUE + celda, end='')  # Terreno difícil
                elif celda == '~':
                    print(Fore.CYAN + celda, end='')  # Agua/pantano
                else:
                    print(celda, end='')  # Color por defecto
        print()  # Nueva línea después de cada fila

# =============================================================================
# PROGRAMA PRINCIPAL - MENÚ INTERACTIVO
# =============================================================================

def main():
    """
    Función principal que ejecuta el menú interactivo del programa.
    """
    laberinto_actual = None  # Almacena el laberinto cargado actualmente
    ruta_laberinto = "laberinto.txt"  # Ruta por defecto

    # Bucle principal del menú
    while True:
        print("\n" + "="*40)
        print("        MENÚ PRINCIPAL")
        print("="*40)
        print("1) Resolver con BFS")
        print("2) Resolver con DFS") 
        print("3) Resolver con UCS")
        print("4) Cambiar laberinto")
        print("5) Salir")
        print("="*40)
        
        opcion = input("Elige una opción (1-5): ").strip()

        # Opciones 1-3: Ejecutar algoritmos de búsqueda
        if opcion in ['1', '2', '3']:
            # Verifica si hay un laberinto cargado
            if laberinto_actual is None:
                if os.path.exists(ruta_laberinto):
                    print(f"\nCargando laberinto por defecto: {ruta_laberinto}")
                    laberinto_actual = cargar_laberinto(ruta_laberinto)
                else:
                    print("\nError: No hay un laberinto cargado. Use la opción 4 primero.")
                    continue

            # Verifica que el laberinto tenga punto de inicio
            if not encontrar_inicio(laberinto_actual):
                print("\nError: El laberinto no tiene punto de inicio (S).")
                continue

            # Ejecuta el algoritmo seleccionado con medición de tiempo
            inicio_tiempo = time.time()
            
            if opcion == '1':
                camino, costo_total, nodos_visitados, longitud = bfs(laberinto_actual)
                alg_nombre = "BFS"
            elif opcion == '2':
                camino, costo_total, nodos_visitados, longitud = dfs(laberinto_actual)
                alg_nombre = "DFS"
            else:
                camino, costo_total, nodos_visitados, longitud = ucs(laberinto_actual)
                alg_nombre = "UCS"
                
            fin_tiempo = time.time()

            # Muestra resultados de la ejecución
            print(f"\n{'='*50}")
            print(f"RESULTADOS CON {alg_nombre}")
            print(f"{'='*50}")
            print(f"Tiempo de ejecución: {(fin_tiempo - inicio_tiempo) * 1000:.3f} ms")
            print(f"Nodos visitados: {nodos_visitados}")
            
            if camino:
                print(f"Longitud del camino: {longitud} pasos")
                print(f"Costo total: {costo_total}")
                
                # Guarda la solución en archivo
                archivo_salida = f"solucion_{alg_nombre.lower()}.txt"
                guardar_solucion(laberinto_actual, camino, archivo_salida)
                print(f"Solución guardada en: '{archivo_salida}'")

                # Pregunta si mostrar visualización
                ver = input("\n¿Ver laberinto con solución? (s/n): ").strip().lower()
                if ver == 's':
                    print(f"\nLaberinto resuelto con {alg_nombre}:")
                    imprimir_laberinto_color(laberinto_actual, camino)
            else:
                print(" No se encontró solución para el laberinto.")
                print("\nLaberinto original:")
                imprimir_laberinto_color(laberinto_actual)

        # Opción 4: Cambiar laberinto
        elif opcion == '4':
            nueva_ruta = input("Ingrese la ruta del archivo de laberinto: ").strip()
            nuevo_laberinto = cargar_laberinto(nueva_ruta)
            
            if nuevo_laberinto is not None:
                laberinto_actual = nuevo_laberinto
                ruta_laberinto = nueva_ruta
                print(f"\n Laberinto '{nueva_ruta}' cargado correctamente.")
                print("\nLaberinto actual:")
                imprimir_laberinto_color(laberinto_actual)

        # Opción 5: Salir del programa
        elif opcion == '5':
            print("\n¡Gracias por usar el resolvedor de laberintos!")
            print("¡Hasta pronto! 👋")
            break

        # Opción inválida
        else:
            print("\n Opción no válida. Por favor elija 1, 2, 3, 4 o 5.")

# Punto de entrada del programa
if __name__ == "__main__":
    main()