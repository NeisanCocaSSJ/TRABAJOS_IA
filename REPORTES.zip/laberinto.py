import collections
import time
import os
from colorama import init, Fore, Back, Style

init(autoreset=True)

def cargar_laberinto(ruta):
    """
    Carga un laberinto desde un archivo de texto.
    Retorna una matriz (lista de listas) de caracteres.
    """
    try:
        with open(ruta, 'r') as archivo:
            laberinto = [list(linea.strip()) for linea in archivo.readlines()]
        return laberinto
    except FileNotFoundError:
        print(f"\nError: El archivo '{ruta}' no se encontró.")
        return None
    except Exception as e:
        print(f"\nError inesperado al leer el archivo: {e}")
        return None

def encontrar_inicio(laberinto):
    """
    Encuentra las coordenadas del punto de inicio 'S' en el laberinto.
    Retorna una tupla (fila, columna).
    """
    for i, fila in enumerate(laberinto):
        for j, celda in enumerate(fila):
            if celda == 'S':
                return (i, j)
    return None

def es_valido(laberinto, fila, col, visitados):
    """
    Verifica si una celda es transitable y no ha sido visitada.
    """
    # 1. Verificar que esté dentro de los límites del laberinto
    if fila < 0 or fila >= len(laberinto) or col < 0 or col >= len(laberinto[0]):
        return False
    # 2. Verificar que no sea una pared y no haya sido visitada
    if laberinto[fila][col] == '#' or (fila, col) in visitados:
        return False
    return True

def bfs(laberinto):
    """
    Resuelve el laberinto usando Búsqueda en Anchura (BFS).
    Retorna el camino solución, nodos visitados y longitud del camino.
    """
    inicio = encontrar_inicio(laberinto)
    if not inicio:
        return None, 0, 0

    # Cola para BFS: almacena (fila, columna, camino_hasta_aqui)
    cola = collections.deque()
    cola.append((inicio[0], inicio[1], [inicio])) # Inicia con el nodo S y su camino
    visitados = set()
    visitados.add(inicio)
    nodos_visitados = 0

    # Direcciones: Arriba, Abajo, Izquierda, Derecha
    direcciones = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while cola:
        fila_actual, col_actual, camino_actual = cola.popleft()
        nodos_visitados += 1

        # Verificar si es la meta
        if laberinto[fila_actual][col_actual] == 'G':
            longitud = len(camino_actual) - 1 # Los pasos son entre nodos
            return camino_actual, nodos_visitados, longitud

        # Explorar vecinos
        for df, dc in direcciones:
            nueva_fila, nueva_col = fila_actual + df, col_actual + dc
            if es_valido(laberinto, nueva_fila, nueva_col, visitados):
                nuevo_camino = camino_actual + [(nueva_fila, nueva_col)]
                cola.append((nueva_fila, nueva_col, nuevo_camino))
                visitados.add((nueva_fila, nueva_col))

    return None, nodos_visitados, 0 # No se encontró solución

def dfs(laberinto):
    """
    Resuelve el laberinto usando Búsqueda en Profundidad (DFS).
    Retorna el camino solución, nodos visitados y longitud del camino.
    """
    inicio = encontrar_inicio(laberinto)
    if not inicio:
        return None, 0, 0

    # Pila para DFS: almacena (fila, columna, camino_hasta_aqui)
    pila = []
    pila.append((inicio[0], inicio[1], [inicio]))
    visitados = set()
    visitados.add(inicio)
    nodos_visitados = 0

    direcciones = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while pila:
        fila_actual, col_actual, camino_actual = pila.pop()
        nodos_visitados += 1

        if laberinto[fila_actual][col_actual] == 'G':
            longitud = len(camino_actual) - 1
            return camino_actual, nodos_visitados, longitud

        for df, dc in direcciones:
            nueva_fila, nueva_col = fila_actual + df, col_actual + dc
            if es_valido(laberinto, nueva_fila, nueva_col, visitados):
                nuevo_camino = camino_actual + [(nueva_fila, nueva_col)]
                pila.append((nueva_fila, nueva_col, nuevo_camino))
                visitados.add((nueva_fila, nueva_col))

    return None, nodos_visitados, 0

def guardar_solucion(laberinto, camino, nombre_archivo):
    """
    Guarda el laberinto con el camino solución en un archivo de texto.
    """
    # Crear una copia del laberinto para no modificar el original
    laberinto_copia = [fila.copy() for fila in laberinto]

    # Marcar el camino en la copia (excepto el inicio y la meta)
    for paso in camino:
        fila, col = paso
        if laberinto_copia[fila][col] not in ['S', 'G']:
            laberinto_copia[fila][col] = '*'

    # Escribir el laberinto modificado en el archivo
    with open(nombre_archivo, 'w') as archivo:
        for fila in laberinto_copia:
            linea = ''.join(fila)
            archivo.write(linea + '\n')

def imprimir_laberinto_color(laberinto, camino=None):
    """
    Imprime el laberinto en la consola con colores.
    Si se proporciona un camino, los pasos se marcan en verde.
    """
    for i, fila in enumerate(laberinto):
        for j, celda in enumerate(fila):
            if camino and (i, j) in camino:
                # Colorear el camino (excluyendo inicio y meta que tienen su propio color)
                if celda == 'S':
                    print(Fore.YELLOW + celda, end='')
                elif celda == 'G':
                    print(Fore.RED + celda, end='')
                else:
                    print(Fore.GREEN + '*', end='')
            else:
                # Colorear sin camino
                if celda == 'S':
                    print(Fore.YELLOW + celda, end='')
                elif celda == 'G':
                    print(Fore.RED + celda, end='')
                elif celda == '#':
                    print(Style.DIM + celda, end='')  # Paredes tenues
                else:
                    print(celda, end='')
        print()  # Nueva línea después de cada fila

def main():
    laberinto_actual = None
    ruta_laberinto = "laberinto.txt" # Ruta por defecto

    while True:
        print("\n=== Menú Principal ===")
        print("1) Resolver con BFS")
        print("2) Resolver con DFS")
        print("3) Cambiar laberinto")
        print("4) Salir")
        opcion = input("Elige una opción: ").strip()

        if opcion == '1' or opcion == '2':
            # Cargar laberinto por defecto si no hay uno cargado
            if laberinto_actual is None:
                if os.path.exists(ruta_laberinto):
                    print(f"\nCargando laberinto por defecto: {ruta_laberinto}")
                    laberinto_actual = cargar_laberinto(ruta_laberinto)
                else:
                    print("\nError: No hay un laberinto cargado. Use la opción 3 primero.")
                    continue

            # Verificar que el laberinto tenga inicio y meta
            if not encontrar_inicio(laberinto_actual):
                print("\nError: El laberinto no tiene punto de inicio (S).")
                continue

            # Ejecutar el algoritmo seleccionado y medir el tiempo
            inicio_tiempo = time.time()
            if opcion == '1':
                camino, nodos_visitados, longitud = bfs(laberinto_actual)
                alg_nombre = "BFS"
            else:
                camino, nodos_visitados, longitud = dfs(laberinto_actual)
                alg_nombre = "DFS"
            fin_tiempo = time.time()

            # Mostrar resultados
            print(f"\n--- Resultados con {alg_nombre} ---")
            print(f"Tiempo de ejecución: {fin_tiempo - inicio_tiempo:.6f} segundos")
            print(f"Nodos visitados: {nodos_visitados}")
            if camino:
                print(f"Longitud del camino solución: {longitud} pasos")
                # Guardar la solución
                archivo_salida = f"solucion_{alg_nombre.lower()}.txt"
                guardar_solucion(laberinto_actual, camino, archivo_salida)
                print(f"Solucion guardada en '{archivo_salida}'")

                # Mostrar el laberinto con colores
                print("\nLaberinto resuelto:")
                imprimir_laberinto_color(laberinto_actual, camino)
            else:
                print("No se encontró solución para el laberinto.")
                # Mostrar el laberinto original
                print("\nLaberinto original:")
                imprimir_laberinto_color(laberinto_actual)

        elif opcion == '3':
            nueva_ruta = input("Ingrese la ruta del nuevo archivo de laberinto: ").strip()
            nuevo_laberinto = cargar_laberinto(nueva_ruta)
            if nuevo_laberinto is not None:
                laberinto_actual = nuevo_laberinto
                ruta_laberinto = nueva_ruta
                print(f"\nLaberinto '{nueva_ruta}' cargado correctamente.")
                # Mostrar el nuevo laberinto
                imprimir_laberinto_color(laberinto_actual)

        elif opcion == '4':
            print("¡Hasta luego!")
            break

        else:
            print("Opción no válida. Por favor, elija 1, 2, 3 o 4.")

if __name__ == "__main__":
    main()