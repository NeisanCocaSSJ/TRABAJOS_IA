#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Tic Tac Toe con IA usando Minimax y Poda Alfa-Beta
Ejecutar: python3 TicTacToe.py
"""

import math
import time

class TicTacToe:
    def __init__(self):
        self.board = [' ' for _ in range(9)]  # Tablero de 3x3
        self.current_winner = None
    
    def print_board(self):
        """Imprime el tablero actual con formato"""
        print("\n" + "="*13)
        for row in [self.board[i*3:(i+1)*3] for i in range(3)]:
            print('| ' + ' | '.join(row) + ' |')
            print("="*13)
    
    @staticmethod
    def print_board_nums():
        """Muestra los números de las posiciones para referencia"""
        print("\nPosiciones del tablero:")
        print("="*13)
        number_board = [[str(i) for i in range(j*3, (j+1)*3)] for j in range(3)]
        for row in number_board:
            print('| ' + ' | '.join(row) + ' |')
            print("="*13)
    
    def available_moves(self):
        """Retorna lista de movimientos disponibles"""
        return [i for i, spot in enumerate(self.board) if spot == ' ']
    
    def empty_squares(self):
        """Verifica si hay casillas vacías"""
        return ' ' in self.board
    
    def num_empty_squares(self):
        """Cuenta casillas vacías"""
        return self.board.count(' ')
    
    def make_move(self, square, letter):
        """Realiza un movimiento y verifica si hay ganador"""
        if self.board[square] == ' ':
            self.board[square] = letter
            if self.check_winner(square, letter):
                self.current_winner = letter
            return True
        return False
    
    def check_winner(self, square, letter):
        """Verifica si hay un ganador después del movimiento"""
        # Revisar fila
        row_ind = square // 3
        row = self.board[row_ind*3 : (row_ind+1)*3]
        if all([spot == letter for spot in row]):
            return True
        
        # Revisar columna
        col_ind = square % 3
        column = [self.board[col_ind+i*3] for i in range(3)]
        if all([spot == letter for spot in column]):
            return True
        
        # Revisar diagonales (solo si es posición diagonal)
        if square % 2 == 0:
            diagonal1 = [self.board[i] for i in [0, 4, 8]]  # Diagonal principal
            if all([spot == letter for spot in diagonal1]):
                return True
            diagonal2 = [self.board[i] for i in [2, 4, 6]]  # Diagonal secundaria
            if all([spot == letter for spot in diagonal2]):
                return True
        
        return False
    
    def reset(self):
        """Reinicia el juego"""
        self.board = [' ' for _ in range(9)]
        self.current_winner = None

# Contador global para análisis de rendimiento
NODOS_EXPANDIDOS = 0

def minimax(board, depth, is_maximizing, alpha, beta):
    #(tablero, profundidad del arbol de decisiones, de quien es el turno en el juego, maximo X, maximo O)
    """
    Implementación de Minimax con poda Alfa-Beta
    """
    global NODOS_EXPANDIDOS
    NODOS_EXPANDIDOS += 1
    
    # Verificar estado del juego
    if board.current_winner == 'X':  # IA es 'X' (maximizador)
        return 10 - depth  # Premia victorias más rápidas
    elif board.current_winner == 'O':  # Jugador es 'O' (minimizador)
        return -10 + depth   # Castiga victorias del oponente
    elif not board.empty_squares():  # Empate
        return 0
    
    if is_maximizing:  # Turno de la IA (X)
        #inicia en -infinito porqeu la Ia busca ek maximo valor posible
        max_eval = -math.inf
        for move in board.available_moves():
            # Simular movimiento de la IA (X) disponibles
            board.make_move(move, 'X')
            #EVAL simula una jugada si es buena o mala
            eval = minimax(board, depth + 1, False, alpha, beta)
            # Deshacer movimiento
            board.board[move] = ' '
            board.current_winner = None
            
            max_eval = max(max_eval, eval)
            alpha = max(alpha, eval)
            #ya no explora las jugadas porqeu O defefiende  entonces poda esa rama
            if beta <= alpha:
                break  # Poda beta
        
        return max_eval
    else:  # Turno del jugador (O)
        #inicia en +infinito porque el HUmano busca minimizar a utilidad de IA
        min_eval = math.inf
        for move in board.available_moves():
            # Simular movimiento del jugador (O)
            board.make_move(move, 'O')
            eval = minimax(board, depth + 1, True, alpha, beta)
            # Deshacer movimiento
            board.board[move] = ' '
            board.current_winner = None
            
            min_eval = min(min_eval, eval)
            #LA IA encontro una mejor jugada y poda esa rama
            beta = min(beta, eval)
            if beta <= alpha:
                break  # Poda alfa
        
        return min_eval

def get_best_move(board):
    """
    Encuentra el mejor movimiento para la IA usando Minimax
    """
    global NODOS_EXPANDIDOS
    NODOS_EXPANDIDOS = 0  # Resetear contador
    
    best_score = -math.inf  # IA es maximizadora ahora
    best_move = None
    start_time = time.time()
    
    # Si es el primer movimiento, elegir centro (óptimo)
    if board.num_empty_squares() == 9:
        return 4
    
    for move in board.available_moves():
        # Probar cada movimiento disponible
        board.make_move(move, 'X')
        score = minimax(board, 0, False, -math.inf, math.inf)  # Cambiado a False
        board.board[move] = ' '
        board.current_winner = None
        
        if score > best_score:  # Cambiado a mayor que
            best_score = score
            best_move = move
    
    end_time = time.time()
    print(f"\n[DEBUG] Tiempo de cálculo: {end_time - start_time:.4f} segundos")
    print(f"[DEBUG] Nodos expandidos: {NODOS_EXPANDIDOS}")
    
    return best_move

def play_game():
    """
    Función principal para jugar
    """
    game = TicTacToe()
    
    print("╔══════════════════════════════════════╗")
    print("║      TIC TAC TOE CON IA - LINUX      ║")
    print("║      Minimax con Poda Alfa-Beta      ║")
    print("╚══════════════════════════════════════╝")
    
    game.print_board_nums()
    print("\n Tú eres 'O', la IA es 'X'")
    print(" La IA inicia primero - ¡Buena suerte!")
    
    # La IA inicia primero
    print("\n Turno de la IA (inicia primero)...")
    first_move = get_best_move(game)
    game.make_move(first_move, 'X')
    print(f" IA elige la posición {first_move}")
    game.print_board()
    
    while game.empty_squares():
        # Turno del jugador humano
        try:
            human_move = int(input("\n Tu turno. Elige una posición (0-8): "))
            
            if human_move < 0 or human_move > 8:
                print(" Error: Elige un número entre 0 y 8")
                continue
                
            if human_move not in game.available_moves():
                print(" Esa posición ya está ocupada. Elige otra.")
                continue
            
            game.make_move(human_move, 'O')
            print(f"\n Moviste a la posición {human_move}")
            game.print_board()
            
            if game.current_winner:
                print("\n ¡Felicidades! ¡Ganaste!")
                return
            
            if not game.empty_squares():
                break
                
            # Turno de la IA
            print("\n Turno de la IA...")
            ai_move = get_best_move(game)
            game.make_move(ai_move, 'X')
            print(f" IA elige la posición {ai_move}")
            game.print_board()
            
            if game.current_winner:
                print("\n ¡La IA gana!")
                return
                
        except ValueError:
            print(" Error: Ingresa un número válido (0-8)")
        except KeyboardInterrupt:
            print("\n\n ¡Juego interrumpido! Hasta luego.")
            return
    
    print("\n ¡Es un empate! Jugaste perfectamente.")

def main():
    """Función principal con menú"""
    while True:
        play_game()
        
        # Preguntar si quiere jugar again
        play_again = input("\n¿Quieres jugar otra vez? (s/n): ").lower()
        if play_again not in ['s', 'si', 'sí', 'y', 'yes']:
            print("¡Gracias por jugar!")
            break

if __name__ == "__main__":
    main()
