import heapq
import math
import time
import os
import copy

# --- Diccionario de costos por tipo de celda ---
COSTOS = {
    '.': 1,    # Camino libre
    ',': 5,    # Terreno difícil
    '~': 10,   # Agua/pantano
    '#': None, # Pared (inaccesible)
    'S': 1,    # Inicio
    'G': 1     # Meta
}

# --- Laberinto base ---
laberinto_base = [
    list("####################"),
    list("#S,,,,,,,,,,,,,,,G#"),
    list("#..#..#.........#.#"),
    list("#..#..#,,,,,,,,,#.#"),
    list("#..#..#.........#.#"),
    list("#..#..#..~~~~~..#.#"),
    list("#..#..##########..#"),
    list("#..#............#.#"),
    list("#..##############.#"),
    list("#.................#"),
    list("####################")
]

# --- Buscar coordenadas de inicio y meta ---
def buscar_simbolo(grid, simbolo):
    for i, fila in enumerate(grid):
        for j, celda in enumerate(fila):
            if celda == simbolo:
                return (i, j)
    return None

# --- Mostrar el laberinto inicial con colores ---
def mostrar_laberinto_colores(grid, inicio, meta):
    os.system('cls' if os.name == 'nt' else 'clear')
    for i, fila in enumerate(grid):
        linea = ""
        for j, celda in enumerate(fila):
            pos = (i, j)
            if pos == inicio:
                linea += '\033[43m\033[30mS\033[0m'   # Fondo amarillo, texto negro
            elif pos == meta:
                linea += '\033[41m\033[30mG\033[0m'   # Fondo rojo, texto negro
            elif celda == '#':
                linea += '\033[100m#\033[0m'          # Fondo gris oscuro
            elif celda == '.':
                linea += '\033[47m\033[30m.\033[0m'   # Fondo blanco, texto negro
            elif celda == ',':
                linea += '\033[46m\033[30m,\033[0m'   # Fondo cyan, texto negro
            elif celda == '~':
                linea += '\033[45m\033[30m~\033[0m'   # Fondo magenta, texto negro
            else:
                linea += celda
        print(linea)
    print()

# --- Heurísticas ---
def heuristica_manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def heuristica_euclidiana(a, b):
    return math.sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)

def heuristica_nula(a, b):
    return 0  # Para UCS

# --- Visualización en consola con colores para el algoritmo ---
def mostrar_laberinto(grid, abiertos, cerrados, ruta, inicio, meta):
    os.system('cls' if os.name == 'nt' else 'clear')
    for i, fila in enumerate(grid):
        linea = ""
        for j, celda in enumerate(fila):
            pos = (i, j)
            if pos in ruta:
                linea += '\033[92m█\033[0m'  # Verde fuerte para la ruta encontrada
            elif pos == inicio:
                linea += '\033[93mS\033[0m'  # Amarillo para inicio
            elif pos == meta:
                linea += '\033[91mG\033[0m'  # Rojo para meta
            elif pos in abiertos:
                linea += '\033[94m·\033[0m'  # Azul para nodos abiertos
            elif pos in cerrados:
                linea += '\033[90m·\033[0m'  # Gris para nodos cerrados
            elif celda == '#':
                linea += '\033[100m#\033[0m' # Fondo gris para paredes
            elif celda == '.':
                linea += '\033[97m.\033[0m'  # Blanco para camino libre
            elif celda == ',':
                linea += '\033[96m,\033[0m'  # Cyan para terreno difícil
            elif celda == '~':
                linea += '\033[95m~\033[0m'  # Magenta para agua/pantano
            else:
                linea += celda
        print(linea)
    print()

    #Cola de prioridad: Los nodos se insertan con una prioridad (el valor f(n) = g(n) + h(n)) 
    #A*: La cola de prioridad asegura que se expandan primero los nodos con menor f(n)
# --- Algoritmo A* ---
def astar(grid, inicio, meta, heuristica, visualizar=False):
    # Frontera de nodos por explorar (cola de prioridad)
    abiertos = []
    heapq.heappush(abiertos, (0, inicio))
    # Diccionarios para almacenar información de los nodos
    padres = {}
    g = {inicio: 0}
    cerrados = set()
    nodos_expandidos = 0
    #Busqueda principal
    """# Extraer el nodo con menor f(n) de la frontera
    _, actual = heapq.heappop(abiertos)
    nodos_expandidos += 1"""
    while abiertos:
        _, actual = heapq.heappop(abiertos)
        nodos_expandidos += 1
        #verifica si alcanzo la meta
        if actual == meta:
            ruta = []
            while actual in padres:
                ruta.append(actual)
                actual = padres[actual]
            ruta.append(inicio)
            ruta.reverse()
            return ruta, g[meta], nodos_expandidos
        #Marca el nodo como expandido
        cerrados.add(actual)
        #Visualizar en tiempo real
        if visualizar:
            abiertos_set = set(pos for _, pos in abiertos)
            ruta_parcial = []
            temp = actual
            while temp in padres:
                ruta_parcial.append(temp)
                temp = padres[temp]
            ruta_parcial.append(inicio)
            mostrar_laberinto(grid, abiertos_set, cerrados, ruta_parcial, inicio, meta)
            time.sleep(0.12)
        #Expande movimientos ortogonales (nodos vecinos)
        for dx, dy in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1), (1,-1), (1,1)]:
            vecino = (actual[0] + dx, actual[1] + dy)
            #Verifica limites del laberinto
            if 0 <= vecino[0] < len(grid) and 0 <= vecino[1] < len(grid[0]):
                celda = grid[vecino[0]][vecino[1]]
                costo_celda = COSTOS.get(celda, None)
                # Saltar celdas inaccesibles o ya expandidas
                if costo_celda is None or vecino in cerrados:
                    continue
                # Calcular nuevo costo acumulado
                nuevo_g = g[actual] + costo_celda
                # Actualizar si encontramos un camino mejor
                if vecino not in g or nuevo_g < g[vecino]:
                    g[vecino] = nuevo_g
                    #A*: La cola de prioridad asegura que se expandan primero los nodos con menor f(n)
                    f = nuevo_g + heuristica(vecino, meta)
                    heapq.heappush(abiertos, (f, vecino))
                    padres[vecino] = actual
    return None, None, nodos_expandidos

"""
#Función f(n): Se calcula como f(n) = g(n) + h(n), donde g(n) es el costo acumulado desde el inicio hasta n, y h(n) es la estimación heurística 
desde n hasta la meta. Esta función es la que prioriza los nodos en la cola.

#abiertos linea 109: Es una lista que funciona como una cola de prioridad (min-heap) y contiene los nodos que están pendientes 
de ser explorados. Cada elemento en abiertos es una tupla (f, nodo), donde f es la prioridad (f = g(n) + h(n)) y nodo son las coordenadas (x, y). 
El heap se organiza de manera que el nodo con el menor valor de f esté en la raíz, por lo que siempre se expande primero el nodo más prometedor.

#g 113: Es un diccionario que almacena el costo acumulado más bajo conocido desde el nodo inicial hasta cada nodo.
 La clave es el nodo (coordenadas) y el valor es el costo acumulado (g(n)). Se actualiza cuando se encuentra un camino con menor costo a un nodo.

#padres 112: Es un diccionario que guarda el nodo padre de cada nodo. Esto permite reconstruir el camino desde la meta hasta el inicio una 
vez que se encuentra la solución. La clave es un nodo y el valor es el nodo desde el cual se llegó a él.

#cerrados 114: Es un conjunto que almacena todos los nodos que ya han sido expandidos. Esto evita volver a expandir nodos que ya han sido procesados, 
 siempre y cuando no se encuentre un camino con menor costo (pero en A* con heurística consistente, no es necesario reabrir nodos).

#ruta 125: Es la lista de nodos que forman el camino desde el inicio hasta la meta. Se reconstruye al llegar a la meta siguiendo los enlaces de padres desde 
la meta hasta el inicio.

#cola de prioridad (f) 161: En este contexto, la cola de prioridad es la lista abiertos manejada con las funciones heapq.heappush y heapq.heappop. 
Garantiza que el nodo con el menor valor de f se extraiga primero.

"""

# --- Algoritmo UCS (Uniform Cost Search) ---
def ucs(grid, inicio, meta, visualizar=False):
    # UCS es equivalente a A* con heurística nula
    return astar(grid, inicio, meta, heuristica_nula, visualizar)

# --- Ejecución y comparación de algoritmos ---
resultados = []
algoritmos = [
    ("Manhattan", heuristica_manhattan),
    ("Euclidiana", heuristica_euclidiana),
    ("UCS", heuristica_nula)
]

for nombre, heuristica in algoritmos:
    print(f"\n--- Usando algoritmo: {nombre} ---")
    laberinto = copy.deepcopy(laberinto_base)
    inicio = buscar_simbolo(laberinto, 'S')
    meta = buscar_simbolo(laberinto, 'G')
    mostrar_laberinto_colores(laberinto, inicio, meta)
    input(f"Presiona ENTER para continuar con {nombre}...")
    t0 = time.time()
    
    if nombre == "UCS":
        ruta, costo, nodos = ucs(laberinto, inicio, meta, visualizar=True)
    else:
        ruta, costo, nodos = astar(laberinto, inicio, meta, heuristica, visualizar=True)
    
    t1 = time.time()
    if ruta:
        print(f"Ruta encontrada: {ruta}")
        print(f"\nLongitud de la ruta: {len(ruta)}")
        print(f"\nCosto total: {costo}")
    else:
        print("\nNo se encontró ruta.")
    print(f"\nNodos visitados: {nodos}")
    print(f"\nTiempo: {(t1-t0)*1000:.2f} ms\n")
    resultados.append([nombre, len(ruta) if ruta else 0, nodos, costo if ruta else "-", f"{(t1-t0)*1000:.2f} ms"])

# --- Tabla comparativa de resultados ---
print("\nTabla comparativa:")
print("\nAlgoritmo   | Pasos | Nodos visitados | Costo | Tiempo")
print("-" * 55)
for r in resultados:
    print("{:11} | {:5} | {:15} | {:5} | {:10}".format(*r))

"""____________________Diferencias clave entre los algoritmos_______________________________________________
UCS: Garantiza optimalidad de coste pero es el menos eficiente en términos de nodos expandidos

*A con Manhattan**: Más eficiente que UCS, especialmente adecuado para movimientos ortogonales

*A con Euclidiana**: Heurística más informada pero puede no ser tan efectiva en entornos con restricciones de movimiento"""